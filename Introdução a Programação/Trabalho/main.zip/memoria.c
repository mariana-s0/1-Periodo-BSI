// Exibi a memoria
void exibirMemoria(int memoria[], int tamanho){  
    int livres = 0,ocupados = 0;
    //Percorre o vetor memória
    for(int i = 0; i < tamanho; i++){
        printf("[%d] ",memoria[i]);
        //Verificando se existe espaço livre
        if(memoria[i] == 0){
            livres++;
        }else
            ocupados++;
    }
    printf("\nQuantidade de blocos livres : %d\n",livres);
    printf("\nQuantidade de blocos ocupados : %d\n",ocupados);
}
//Encontra o primeiro bloco disponível e aloca nele
int alocarFirstFit(int memoria[],int tamanho,int pid,int quantidade,int alocacoes[],int desperdicios[]){ 
    int blocosLivres = 0, totalLivres = 0,i=0;
    //Percorre o vetor de memória , verfica se o PID já existe , incrementa TotalLivres se necessário
    for(i = 0; i < tamanho ; i++){
        if(buscarPID(memoria,tamanho,pid) == 1){
            printf("PID já existente");
            return 0;
        }
        if(memoria[i] == 0){
            totalLivres++; 
        }
    }
    if(totalLivres < quantidade){
        printf("\nEspaço Insuficiente\n");
        return 0;
    }
    //Percorre o vetor , incrementa blocosLivres
    for(i = 0; i < tamanho ; i++){
        if(memoria[i] == 0){
            blocosLivres++;
        } else{
            blocosLivres = 0;
        }
    
        if(blocosLivres >= quantidade){
            int inicio = i - quantidade + 1;
            //Procura o primeiro bloco consecutivo válido e atribui PID
            for(int j = inicio; j <= i; j++){
                memoria[j] = pid;
            }
            alocacoes[0]++;
            desperdicios[0]+=(blocosLivres-quantidade);
            printf("Processo alocado com sucesso\n");
            return 1;
        }
    }
    printf("Fragmentacao externa\n");
    return 0;
}
// Encontra o menor bloco disponível e aloca nele
int alocarBestFit(int memoria[],int tamanho,int pid,int quantidade,int alocacoes[],int desperdicios[]){ 
    int pidExiste = buscarPID(memoria,tamanho,pid);
    int melhorInicio = -1; //Usamos o -1 pois o primeiro índice válido é zero
    int melhorTamanho = tamanho + 1; // Usamos isso para que qualquer  índice encontrado seja o melhor daquela iteração
    int inicioAtual = -1;
    int tamanhoAtual = 0;
    if (pidExiste) {
        printf("PID já existente\n");
        return 0;
    }
    for (int i = 0; i < tamanho; i++) {
        if (memoria[i] == 0) {
            if (tamanhoAtual == 0) {
                inicioAtual = i;
            }
            tamanhoAtual ++;
        } else {
            if (tamanhoAtual >= quantidade && tamanhoAtual < melhorTamanho) {
                melhorTamanho = tamanhoAtual;
                melhorInicio = inicioAtual;
            }
            tamanhoAtual = 0;
        }
    }
    //Verifica o ultimo bloco
    if (tamanhoAtual >= quantidade && tamanhoAtual < melhorTamanho) {
        melhorTamanho = tamanhoAtual;
        melhorInicio = inicioAtual;
    }
    if (melhorInicio == -1) {
        printf("Não existe espaço suficiente");
        return 0;
    }
    //Atribuir PID
    for (int i = melhorInicio; i < melhorInicio + quantidade; i++) {
        memoria[i] = pid;
    }
    alocacoes[1]++;
    desperdicios[1] +=(melhorTamanho - quantidade);
    printf("Alocação realizada com sucesso\n");
    return 1;
}
 //Encontra o maior bloco disponível e alocar nele
int alocarWorstFit(int memoria[],int tamanho,int pid,int quantidade,int alocacoes[],int desperdicios[]){
    int pidExiste = buscarPID(memoria,tamanho,pid);
    int piorInicio = -1; //Usamos o -1 pois o primeiro índice válido é zero
    int piorTamanho = 0; 
    int inicioAtual = -1;
    int tamanhoAtual = 0;
    if (pidExiste) {
        printf("PID já existente\n");
        return 0;
    }
    for (int i = 0; i < tamanho; i++) {
        if (memoria[i] == 0) {
            if (tamanhoAtual == 0) {
                inicioAtual = i;
            }
            tamanhoAtual ++;
        } else {
            if (tamanhoAtual >= quantidade && tamanhoAtual > piorTamanho) {
                piorTamanho = tamanhoAtual;
                piorInicio = inicioAtual;
            }
            tamanhoAtual = 0;
        }
    }
    //Verifica o ultimo bloco
    if (tamanhoAtual >= quantidade && tamanhoAtual > piorTamanho) {
        piorTamanho = tamanhoAtual;
        piorInicio = inicioAtual;
    }
    if (piorInicio == -1) {
        printf("Não existe espaço suficiente");
        return 0;
    }
    //Atribuir PID
    for (int i = piorInicio; i < piorInicio + quantidade; i++) {
        memoria[i] = pid;
    }
    alocacoes[2]++;
    desperdicios[2] +=(piorTamanho - quantidade);
    printf("Alocação realizada com sucesso\n");
    return 1;
}
//Função libera PID 
int liberarProcesso(int memoria[],int tamanho,int pid){
    int pidExiste = buscarPID(memoria, tamanho, pid);
    if(pidExiste == 0){
        printf("PID não encontrado !!");
        return 0;
    }
    for(int i=0; i < tamanho; i++){
        if(memoria[i]== pid){
            memoria[i] = 0;
        }
    }
   
    printf("\nProcessos liberados\n");
    return 1;
}
//Junta as memórias
void compactarMemoria(int memoria[], int tamanho){
    int destino =0;
    int houveCompactacao=0;

    for(int i=0; i < tamanho; i++){
        if(memoria[i] != 0){
            memoria[destino] = memoria[i];
        
            if(i != destino){
                memoria[i]=0;
                houveCompactacao = 1;
            }
            destino++;
        } 
    }
        if(houveCompactacao == 1){
            printf("\nMemória compactada com sucesso\n");
        }
        else 
            printf("\nNão há nada para compactar\n");
}
//Cria um relatória de memória
void relatorioMemoria(int memoria[],int tamanho){
    int ocupados =0 ,livres =0;
    //blocos livres e ocupados
    for(int i=0; i < tamanho; i++){
        printf("[%d] ",memoria[i]);
        if(memoria[i]==0){
            livres++;
        }else
            ocupados++;             
    }
    printf("\nTotal de blocos : %d\n",tamanho);
    printf("\nQuantidade de blocos livres : %d\n",livres);
    printf("\nQuantidade de blocos ocupados : %d\n",ocupados);
    printf("\nPercentual de ocupação : %.2f\n",((float)ocupados/tamanho)*100);
    printf("\nMaior bloco consecutivo livre : %d\n",maiorBlocoLivre(memoria,tamanho));
    printf("\nQuantidade de fragmentos livres : %d\n",contarFragmentos(memoria,tamanho));
}
void relatorioEficiencia(int alocacoes[], int desperdicios[]){
    float mediaFF=0,mediaBF=0 ,mediaWF=0,menorMedia=999999;
    int melhorEstrategia=-1;
    //Verifica se nenhuma alocação foi realizada
    if(alocacoes[0] == 0 && alocacoes[1] == 0 && alocacoes[2] == 0){
        printf("\nNenhuma alocacao realizada\n");
        return ;
    }
    if(alocacoes[0] > 0){
        mediaFF =(float)desperdicios[0] / alocacoes[0];
    }
    if(alocacoes[1] > 0){
        mediaBF =
        (float)desperdicios[1] / alocacoes[1];
    }
    if(alocacoes[2] > 0){
        mediaWF =
        (float)desperdicios[2] / alocacoes[2];
    }
    printf("\n===== RELATORIO DE EFICIENCIA =====\n");

    printf("\nFIRST FIT\n");
    printf("\nQuantidade de alocacoes: %d\n",alocacoes[0]);
    printf("\nDesperdicio total: %d\n",desperdicios[0]);
    printf("\nDesperdicio medio: %.2f\n",mediaFF);
    printf("\nBEST FIT\n");
    printf("\nQuantidade de alocacoes: %d\n",alocacoes[1]);
    printf("\nDesperdicio total: %d\n",desperdicios[1]);
    printf("\nDesperdicio medio: %.2f\n",mediaBF);
    printf("\nWORST FIT\n");
    printf("\nQuantidade de alocacoes: %d\n",alocacoes[2]);
    printf("\nDesperdicio total: %d\n",desperdicios[2]);
    printf("\nDesperdicio medio: %.2f\n",mediaWF);
    //Descobrir o menor desperdicio médio
    if(alocacoes[0] > 0 && mediaFF < menorMedia){
        menorMedia = mediaFF;
        melhorEstrategia = 0;
    }
    if(alocacoes[1] > 0 && mediaBF < menorMedia){
        menorMedia = mediaBF;
        melhorEstrategia = 1;
    }
    if(alocacoes[2] > 0 && mediaWF < menorMedia){
        menorMedia = mediaWF;
        melhorEstrategia = 2;
    }
    printf("\nMelhor estrategia:\n");
    if(melhorEstrategia == 0){
        printf("\nFirst Fit\n");
    }
    else if(melhorEstrategia == 1){
        printf("\nBest Fit\n");
    }
    else if(melhorEstrategia == 2){
        printf("\nWorst Fit\n");
    }
}
//Encontra o maior bloco livre disponível
int maiorBlocoLivre(int memoria[],int tamanho) { 
    int tamanhoAtual = 0, maiorTamanho = 0;
    for(int i = 0; i < tamanho; i++) {
        if (memoria[i] == 0) {
            tamanhoAtual ++;
        } else {
            if (tamanhoAtual > maiorTamanho) {
                maiorTamanho = tamanhoAtual;
            }
            tamanhoAtual = 0;
        }
    }
    if (tamanhoAtual > maiorTamanho) {
        maiorTamanho = tamanhoAtual;
    }
    return maiorTamanho;
}
//Conta a quantidade de fragmentos
int contarFragmentos(int memoria[],int tamanho){ 
    int fragmentos=0;
    for(int i=0; i < tamanho; i++){
        if(memoria[i]==0){
            if( i == 0 || memoria [ i -1] != 0){
                fragmentos++;
            }
        }
    }
    return fragmentos;
}
//Função para verificar se existe um PID
int buscarPID(int memoria[],int tamanho,int pid){
    //Percorre o vetor memória , e retorna 1 se o PID for existente
    for(int i = 0; i < tamanho ; i++){
        if(memoria[i] == pid){
            return 1;
        }
    }
    return 0;
}